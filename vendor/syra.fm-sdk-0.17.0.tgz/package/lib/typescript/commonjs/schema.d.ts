import { z } from 'zod';
/**
 * Minimal, self-contained schemas for the public Syra API response shapes this
 * SDK consumes. Intentionally NOT shared with the Syra backend's internal
 * types — the SDK validates only the fields it returns, and tolerantly strips
 * everything else (Zod object schemas drop unknown keys by default), so the API
 * can evolve without breaking external consumers.
 */
/** A single artwork variant. The backend serializes `url` as `/api/images/:id`. */
export declare const coverArtVariantSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    url: z.ZodString;
    width: z.ZodOptional<z.ZodNumber>;
    height: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type CoverArtVariant = z.infer<typeof coverArtVariantSchema>;
/** Named artwork variants keyed by size. */
export declare const coverArtSizesSchema: z.ZodObject<{
    small: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    medium: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    large: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    xlarge: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    xxlarge: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    original: z.ZodOptional<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type CoverArtSizes = z.infer<typeof coverArtSizesSchema>;
/** Artwork size name. */
export type ArtworkSize = keyof CoverArtSizes;
/**
 * The summary view of a track returned by the public catalog endpoints — just
 * enough to render a song row and play its preview.
 */
export declare const trackSummarySchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    artistId: z.ZodOptional<z.ZodString>;
    artistName: z.ZodString;
    albumId: z.ZodOptional<z.ZodString>;
    albumName: z.ZodOptional<z.ZodString>;
    duration: z.ZodNumber;
    coverArt: z.ZodOptional<z.ZodString>;
    coverArtSizes: z.ZodOptional<z.ZodObject<{
        small: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        medium: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        large: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xxlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        original: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    previewAvailable: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type TrackSummary = z.infer<typeof trackSummarySchema>;
/**
 * The summary view of a podcast SHOW returned by the public podcast endpoints
 * (`GET /api/podcasts/search`, `GET /api/podcasts/:id`) — just enough to render
 * a show card and deep-link into the Syra app.
 *
 * Artwork mirrors tracks: `image` is the re-hosted Syra image id (resolved via
 * `/api/images/:id`); `imageSizes` is the multi-resolution variant set (each
 * variant `url` is `/api/images/:id`); `imageSourceUrl` keeps the original
 * external artwork URL as an absolute fallback when re-hosting has not run yet.
 */
export declare const podcastVisibilitySchema: z.ZodEnum<{
    private: "private";
    unlisted: "unlisted";
    public: "public";
}>;
export type PodcastVisibility = z.infer<typeof podcastVisibilitySchema>;
export declare const podcastSummarySchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    author: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodString>;
    imageSizes: z.ZodOptional<z.ZodObject<{
        small: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        medium: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        large: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xxlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        original: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    imageSourceUrl: z.ZodOptional<z.ZodString>;
    visibility: z.ZodOptional<z.ZodEnum<{
        private: "private";
        unlisted: "unlisted";
        public: "public";
    }>>;
    aiGenerated: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type PodcastSummary = z.infer<typeof podcastSummarySchema>;
/**
 * One show the caller is subscribed to, from `GET /api/podcasts/subscriptions`.
 * `lastEpisodeAt` is the newest episode's publish time — what a client compares
 * against its own last visit to badge a show with new episodes.
 */
export declare const podcastSubscriptionSchema: z.ZodObject<{
    podcast: z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        author: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodString>;
        imageSizes: z.ZodOptional<z.ZodObject<{
            small: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            medium: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            large: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            xlarge: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            xxlarge: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            original: z.ZodOptional<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                url: z.ZodString;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        imageSourceUrl: z.ZodOptional<z.ZodString>;
        visibility: z.ZodOptional<z.ZodEnum<{
            private: "private";
            unlisted: "unlisted";
            public: "public";
        }>>;
        aiGenerated: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    lastEpisodeAt: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type PodcastSubscription = z.infer<typeof podcastSubscriptionSchema>;
/**
 * The summary view of a podcast EPISODE returned by the public podcast endpoints
 * (`GET /api/podcasts/:id/episodes`, `GET /api/episodes/:id`) — just enough to
 * list an episode and stream its audio.
 *
 * ## `enclosureUrl` is OPTIONAL, and that is a bug fix rather than a loosening
 *
 * It used to be required, on the reasoning that "an episode with no enclosure is
 * unplayable, so a row missing it is malformed". That reasoning holds only for
 * RSS-mirrored episodes. A SYRA-HOSTED episode — everything created through
 * `createPodcast`/`uploadEpisode`/the ingest ticket — has no enclosure at all:
 * its audio lives at `audioSource.url`, a path on the Syra API. So the required
 * field made this SDK silently DROP every Syra-hosted episode from
 * `getPodcastEpisodes` and throw on one from `getEpisode` — the entire
 * first-party catalogue, invisible, with no error to notice.
 *
 * The two are alternatives, not a required field and an optional one:
 *
 *   enclosureUrl      an ABSOLUTE external URL (RSS mirror)
 *   audioSource.url   a PATH on the Syra API (Syra-hosted)
 *
 * `SyraClient.episodeAudioUrl` is the one place that resolves either into
 * something playable, so no consumer has to know which kind it holds.
 *
 * `enclosureType` / `enclosureLength` describe the external file (MIME type and
 * byte length); `duration` is the runtime in seconds and `pubDate` the ISO
 * publish timestamp.
 *
 * Artwork mirrors the podcast SHOW: `image` is the re-hosted Syra image id
 * (resolved via `/api/images/:id`); `imageSizes` is the multi-resolution variant
 * set (each variant `url` is `/api/images/:id`); `imageSourceUrl` keeps the
 * original external artwork URL as an absolute fallback when re-hosting has not
 * run yet.
 */
/**
 * Where a Syra-hosted episode's audio actually is.
 *
 * `url` is a PATH on the Syra API (`/api/podcasts/episodes/:id/audio`), not an
 * absolute URL — resolve it with `SyraClient.episodeAudioUrl` rather than
 * handing it to a player directly.
 */
export declare const episodeAudioSourceSchema: z.ZodObject<{
    url: z.ZodString;
    format: z.ZodOptional<z.ZodString>;
    bitrate: z.ZodOptional<z.ZodNumber>;
    duration: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type EpisodeAudioSource = z.infer<typeof episodeAudioSourceSchema>;
/**
 * An episode's processing state. `ready` is playable; `processing` is an episode
 * whose audio is still being packaged (including one drafted but not yet
 * ingested), and only its OWNER is shown those.
 */
export declare const episodeStatusSchema: z.ZodEnum<{
    ready: "ready";
    processing: "processing";
    failed: "failed";
    unavailable: "unavailable";
}>;
export type EpisodeStatus = z.infer<typeof episodeStatusSchema>;
export declare const episodeSummarySchema: z.ZodObject<{
    id: z.ZodString;
    podcastId: z.ZodString;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    enclosureUrl: z.ZodOptional<z.ZodString>;
    enclosureType: z.ZodOptional<z.ZodString>;
    enclosureLength: z.ZodOptional<z.ZodNumber>;
    audioSource: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        format: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    duration: z.ZodOptional<z.ZodNumber>;
    pubDate: z.ZodOptional<z.ZodString>;
    season: z.ZodOptional<z.ZodNumber>;
    episodeNumber: z.ZodOptional<z.ZodNumber>;
    status: z.ZodOptional<z.ZodEnum<{
        ready: "ready";
        processing: "processing";
        failed: "failed";
        unavailable: "unavailable";
    }>>;
    aiGenerated: z.ZodOptional<z.ZodBoolean>;
    image: z.ZodOptional<z.ZodString>;
    imageSizes: z.ZodOptional<z.ZodObject<{
        small: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        medium: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        large: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        xxlarge: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        original: z.ZodOptional<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            url: z.ZodString;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    imageSourceUrl: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type EpisodeSummary = z.infer<typeof episodeSummarySchema>;
/** What `createEpisodeDraft` hands back: the episode to fill, and the capability to fill it. */
export declare const episodeDraftSchema: z.ZodObject<{
    episodeId: z.ZodString;
    ingestTicket: z.ZodString;
    expiresAt: z.ZodString;
}, z.core.$strip>;
export type EpisodeDraft = z.infer<typeof episodeDraftSchema>;
/**
 * What `deletePodcast` hands back — a receipt, and it is worth reading rather
 * than discarding.
 *
 * Both counts are of things that were actually removed by THIS call, so they are
 * how a caller mirroring the delete elsewhere can tell a real deletion from a
 * no-op. `objectsDeleted` counts stored objects (source audio, manifests and
 * every segment beside them); a show whose episodes were never ingested reports
 * zero for both, which is a success, not a failure.
 */
export declare const podcastDeletedSchema: z.ZodObject<{
    id: z.ZodString;
    episodesDeleted: z.ZodNumber;
    objectsDeleted: z.ZodNumber;
}, z.core.$strip>;
export type PodcastDeleted = z.infer<typeof podcastDeletedSchema>;
/** What `deleteEpisode` hands back. `podcastId` names the show it was removed from. */
export declare const episodeDeletedSchema: z.ZodObject<{
    id: z.ZodString;
    podcastId: z.ZodString;
    objectsDeleted: z.ZodNumber;
}, z.core.$strip>;
export type EpisodeDeleted = z.infer<typeof episodeDeletedSchema>;
/** What `getEpisodeStream` hands back: a tokenized HLS URL with its own deadline. */
export declare const episodeStreamSchema: z.ZodObject<{
    url: z.ZodString;
    type: z.ZodString;
    expiresAt: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type EpisodeStream = z.infer<typeof episodeStreamSchema>;
/** What the image upload endpoint hands back. */
export declare const uploadedImageSchema: z.ZodObject<{
    id: z.ZodString;
    primaryColor: z.ZodOptional<z.ZodString>;
    secondaryColor: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type UploadedImage = z.infer<typeof uploadedImageSchema>;
//# sourceMappingURL=schema.d.ts.map