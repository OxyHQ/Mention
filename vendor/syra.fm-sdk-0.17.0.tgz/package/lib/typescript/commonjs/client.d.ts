import { type PublicPodcastCardsResponse } from '@syra.fm/contracts';
import { type TrackSummary, type PodcastSummary, type PodcastSubscription, type EpisodeSummary, type EpisodeDraft, type EpisodeStream, type UploadedImage, type PodcastDeleted, type EpisodeDeleted, type PodcastVisibility, type CoverArtSizes, type ArtworkSize } from './schema';
/** Default base URL of the public Syra API. */
export declare const DEFAULT_SYRA_BASE_URL = "https://api.syra.fm";
/** Default base URL of the Syra web app, used for deep links. */
export declare const DEFAULT_SYRA_WEB_BASE_URL = "https://syra.fm";
export interface SyraClientOptions {
    /** Base URL of the Syra API. Defaults to {@link DEFAULT_SYRA_BASE_URL}. */
    baseURL?: string;
    /**
     * Base URL of the Syra WEB app (not the API host), used to build deep links
     * such as {@link SyraClient.podcastUrl}. Defaults to
     * {@link DEFAULT_SYRA_WEB_BASE_URL}.
     */
    webBaseURL?: string;
    /**
     * `fetch` implementation. Defaults to the global `fetch` (Node 18+, browsers,
     * React Native). Inject one (e.g. `node-fetch`) when no global is available.
     */
    fetch?: typeof fetch;
    /**
     * Supplies the caller's Oxy access token. Called BEFORE EVERY REQUEST, never
     * cached here, because an access token is short-lived and the host
     * application is the only thing that knows when it was refreshed — an SDK
     * holding its own copy is an SDK that starts sending an expired one.
     *
     * Returning `null`/`undefined` means "no session right now", which is a normal
     * state and not an error: every PUBLIC read below still works without a token,
     * exactly as it did before this existed. Only the authenticated methods refuse,
     * and they say so by name.
     *
     * The token IS sent on public reads when it is available, which is
     * deliberate — it is what lets an owner see their own private show and their
     * own unpublished episodes through the same methods everyone else uses.
     */
    getAccessToken?: () => string | null | undefined | Promise<string | null | undefined>;
}
export interface SearchTracksOptions {
    /** Maximum number of tracks to request from the API (the page size). */
    limit?: number;
    /** Zero-based offset of the first track to return (for infinite scroll). */
    offset?: number;
}
export interface SearchPodcastsOptions {
    /** Maximum number of podcast shows to request from the API (the page size). */
    limit?: number;
    /** Zero-based offset of the first show to return (for infinite scroll). */
    offset?: number;
}
export interface PodcastEpisodesOptions {
    /** Maximum number of episodes to request from the API (the page size). */
    limit?: number;
    /** Zero-based offset of the first episode to return (for infinite scroll). */
    offset?: number;
}
/**
 * One page of paginated catalog search results.
 *
 * `hasMore` reflects the BACKEND's pagination over the full matching set — NOT
 * `items.length`. {@link SyraClient.searchTracks} additionally filters its page
 * client-side to preview-available tracks, so `items.length` can be smaller than
 * `limit` while `hasMore` is still `true`; callers must paginate by advancing
 * `offset` by `limit` (the page size), never by `items.length`.
 */
export interface SearchPage<T> {
    /** The validated rows for this page. */
    items: T[];
    /** Whether the backend has results beyond this page. */
    hasMore: boolean;
    /** The page size the backend applied. */
    limit: number;
    /** The zero-based offset of this page. */
    offset: number;
}
/** Minimal shape from which track artwork URLs can be derived. */
export interface ArtworkSource {
    coverArt?: string | null;
    coverArtSizes?: CoverArtSizes | null;
}
/** Minimal shape from which podcast-show artwork URLs can be derived. */
export interface PodcastArtworkSource {
    image?: string | null;
    imageSizes?: CoverArtSizes | null;
    imageSourceUrl?: string | null;
}
/** Minimal shape from which podcast-episode artwork URLs can be derived. */
export interface EpisodeArtworkSource {
    image?: string | null;
    imageSizes?: CoverArtSizes | null;
    imageSourceUrl?: string | null;
}
/** The fields `createPodcast` accepts. Mirrors `POST /api/podcasts`. */
export interface CreatePodcastInput {
    title: string;
    description?: string;
    author?: string;
    /** An image id from {@link SyraClient.uploadPodcastImage}, not a URL. */
    image?: string;
    language?: string;
    categories?: string[];
    explicit?: boolean;
    link?: string;
    type?: 'episodic' | 'serial';
    visibility?: PodcastVisibility;
    /** The Alia series this show was generated from; records `provider: 'alia'` provenance. */
    aliaSeriesId?: string;
    /** Disclosure. Independent of {@link CreatePodcastInput.aliaSeriesId} — neither implies the other. */
    aiGenerated?: boolean;
    /** Hosts & Guests as Oxy user ids. Validated server-side; free text is refused. */
    hosts?: string[];
    guests?: string[];
}
/** The fields `updatePodcast` accepts. Every one is optional; omitted means unchanged. */
export interface UpdatePodcastInput {
    title?: string;
    description?: string;
    author?: string;
    image?: string;
    language?: string;
    categories?: string[];
    explicit?: boolean;
    link?: string;
    type?: 'episodic' | 'serial';
    visibility?: PodcastVisibility;
    aiGenerated?: boolean;
}
/** The metadata `createEpisodeDraft` accepts — everything except the audio. */
export interface CreateEpisodeDraftInput {
    title: string;
    description?: string;
    summary?: string;
    season?: number;
    episodeNumber?: number;
    episodeType?: 'full' | 'trailer' | 'bonus';
    explicit?: boolean;
    aiGenerated?: boolean;
    hosts?: string[];
    guests?: string[];
}
/**
 * The metadata the ingest step may set.
 *
 * Deliberately SMALLER than {@link CreateEpisodeDraftInput}, and it is not an
 * oversight: the ticket is redeemed by a process with no user session, so the
 * server accepts only what such a process can know by having produced the
 * episode. Artwork, `explicit`, `episodeType`, credits and the AI disclosure
 * were fixed at draft time by the authenticated user and are refused here.
 *
 * `title` IS accepted, and it is the reason to reach for this at all: a draft is
 * created before the content exists, so its title can only name the topic that
 * was requested. Send the name the FINISHED episode earned and it replaces the
 * draft's.
 *
 * Omitting it keeps whatever the draft said — an absent title never clears one,
 * so a worker that has nothing better than the placeholder can still deliver
 * the audio. A title that is empty or only whitespace is REFUSED (400) rather
 * than stored, the same rule the authenticated endpoints apply; the ticket
 * survives that refusal and can be redeemed again.
 */
export interface IngestEpisodeInput {
    title?: string;
    duration?: number;
    season?: number;
    episodeNumber?: number;
    description?: string;
    summary?: string;
}
/**
 * An audio or image payload, in the shapes the three supported runtimes give you.
 *
 * `Blob`/`File` covers browsers and Node 18+. React Native's `FormData` accepts
 * a `{ uri, name, type }` descriptor instead, which is not a `Blob` at all — it
 * is named here so an RN caller does not have to cast, and so this SDK never has
 * to import anything from React Native to support it.
 */
export type UploadPayload = Blob | {
    uri: string;
    name?: string;
    type?: string;
};
export interface SyraClient {
    /**
     * Search the public catalog for tracks. Returns one paginated page: rows are
     * validated against the track-summary schema and filtered to those that expose
     * a public preview. `hasMore` comes from the backend's pagination, so it is
     * unaffected by the client-side preview filter (see {@link SearchPage}).
     */
    searchTracks(query: string, options?: SearchTracksOptions): Promise<SearchPage<TrackSummary>>;
    /** Fetch a single track by id, validated against the track-summary schema. */
    getTrack(id: string): Promise<TrackSummary>;
    /** Build the public 30s preview URL for a track at the given start offset. */
    previewUrl(id: string, startSec?: number): string;
    /**
     * Resolve an absolute artwork URL from a track / cover-art reference. Returns
     * `undefined` when no artwork can be derived.
     */
    artworkUrl(source: string | ArtworkSource, size?: ArtworkSize): string | undefined;
    /**
     * Search the public catalog for podcast SHOWS (not episodes). Returns one
     * paginated page: rows are validated against the podcast-summary schema and
     * malformed rows are dropped. `hasMore` comes from the backend's pagination.
     */
    searchPodcasts(query: string, options?: SearchPodcastsOptions): Promise<SearchPage<PodcastSummary>>;
    /**
     * Fetch a single podcast show by id, validated against the podcast-summary
     * schema. The by-id endpoint also returns episodes and resolved persons; this
     * returns just the show summary needed to render a card.
     */
    getPodcast(id: string): Promise<PodcastSummary>;
    /** Current public-only show cards. Never sends credentials; no stale response cache. */
    getPublicPodcastCards(ids: readonly string[], options?: {
        signal?: AbortSignal;
    }): Promise<PublicPodcastCardsResponse>;
    /** Build the Syra web app deep link for a podcast show (`/podcasts/:id`). */
    podcastUrl(id: string): string;
    /**
     * Resolve an absolute artwork URL from a podcast show reference. Prefers the
     * re-hosted Syra image, then the requested/fallback variant, then the original
     * external artwork URL. Returns `undefined` when no artwork can be derived.
     */
    podcastArtworkUrl(source: PodcastArtworkSource, size?: ArtworkSize): string | undefined;
    /**
     * List a podcast show's EPISODES (newest first, as the backend orders them).
     * Returns one paginated page: rows are validated against the episode-summary
     * schema and malformed rows are dropped — including any without a playable
     * `enclosureUrl`, which the schema requires. The backend paginates by 1-based
     * `page`, but this keeps the uniform offset-based {@link SearchPage} for parity
     * with {@link SyraClient.searchPodcasts}; paginate by advancing `offset` by
     * `limit` (the page size), never by `items.length`.
     */
    getPodcastEpisodes(podcastId: string, options?: PodcastEpisodesOptions): Promise<SearchPage<EpisodeSummary>>;
    /**
     * Fetch a single episode by id, validated against the episode-summary schema.
     * The by-id endpoint nests the episode under `data.episode` alongside resolved
     * persons; this returns just the episode summary needed to stream its audio.
     */
    getEpisode(episodeId: string): Promise<EpisodeSummary>;
    /**
     * Resolve an absolute artwork URL from a podcast episode reference. Prefers the
     * re-hosted Syra image, then the requested/fallback variant, then the original
     * external artwork URL. Returns `undefined` when no artwork can be derived.
     */
    episodeImageUrl(source: EpisodeArtworkSource, size?: ArtworkSize): string | undefined;
    /**
     * Resolve an episode's PLAYABLE audio URL, whichever kind of episode it is.
     *
     * An RSS-mirrored episode carries an absolute `enclosureUrl`; a Syra-hosted one
     * carries `audioSource.url`, a path on the API. This is the one place that
     * knows the difference, so no consumer has to.
     *
     * `undefined` when the episode has no audio yet — a drafted episode awaiting
     * ingest is a real, listable episode with nothing to play, and answering with
     * a broken URL would be worse than answering with nothing.
     */
    episodeAudioUrl(episode: {
        enclosureUrl?: string | null;
        audioSource?: {
            url?: string | null;
        } | null;
    }): string | undefined;
    /**
     * `POST /api/podcasts/:id/subscribe` — subscribe the caller to a show (what a
     * client presents as "save" or "follow"). Idempotent: subscribing twice is one
     * subscription. A show the caller cannot see is a 404, same as a missing one.
     */
    subscribeToPodcast(podcastId: string): Promise<void>;
    /**
     * `POST /api/podcasts/:id/unsubscribe` — idempotent, and succeeds for every
     * well-formed id, including a show that no longer exists or went private.
     */
    unsubscribeFromPodcast(podcastId: string): Promise<void>;
    /**
     * `GET /api/podcasts/subscriptions` — every show the caller is subscribed to
     * and can still see. A row that fails validation is dropped rather than
     * failing the whole list.
     */
    listPodcastSubscriptions(): Promise<PodcastSubscription[]>;
    /** `GET /api/podcasts/mine` — every show the caller owns, in every state. */
    listMyPodcasts(): Promise<PodcastSummary[]>;
    /** `POST /api/podcasts` — create a Syra-hosted show. */
    createPodcast(input: CreatePodcastInput): Promise<PodcastSummary>;
    /** `PATCH /api/podcasts/:id` — edit a Syra-hosted show you own. */
    updatePodcast(podcastId: string, input: UpdatePodcastInput): Promise<PodcastSummary>;
    /**
     * Change who may see a show. A named affordance over
     * {@link SyraClient.updatePodcast}, because it is the one field with
     * consequences a caller should not discover by reading a diff: making a show
     * `private` withdraws it from every listing AND stops its episodes being
     * transcoded, and publishing it again enqueues the transcodes that were
     * deferred.
     */
    setPodcastVisibility(podcastId: string, visibility: PodcastVisibility): Promise<PodcastSummary>;
    /**
     * `POST /api/images/upload` — store cover art and get the image id back.
     *
     * The id is what {@link CreatePodcastInput.image} wants; a URL is not accepted
     * there, because the API re-hosts artwork rather than hotlinking it.
     */
    uploadPodcastImage(image: UploadPayload, filename?: string): Promise<UploadedImage>;
    /**
     * `DELETE /api/podcasts/:id` — permanently delete a Syra-hosted show you own.
     *
     * IRREVERSIBLE, and it takes more than the show. Verified against the handler
     * and against the migrated schema's own `pg_constraint` rows rather than read
     * off a doc comment:
     *
     * - **Every episode row goes** (`episodes.podcast_id` is `ON DELETE CASCADE`),
     *   and with each one its HLS renditions, transcripts, credits, AES stream
     *   key and any outstanding ingest ticket.
     * - **The audio in S3 goes** — the server sweeps the show's three storage
     *   trees (`hls/{id}/`, `podcasts/audio/{id}/`, `podcasts/cache/{id}/`), so
     *   segments that no row names are removed too. {@link PodcastDeleted.objectsDeleted}
     *   is the count actually deleted.
     * - **Other people's rows go with it**: every listener's saved position
     *   (`episode_progress`) and every subscriber's subscription
     *   (`user_podcast_subscriptions`).
     *
     * **What it does NOT remove: the cover artwork.** `image_assets` is referenced
     * `ON DELETE set null`, and the artwork's S3 objects live under
     * `images/{imageId}/`, which is not one of the three swept trees — so the
     * image rows and their bytes are deliberately left behind. One asset may be
     * referenced by several shows and episodes and nothing records how many, so
     * deleting it could blank a show nobody asked to touch. Reclaiming that
     * storage needs a sweeper that can prove non-reference; it is not this call's
     * job and this call will not do it silently.
     *
     * Two more consequences worth knowing before calling it for real:
     *
     * - The server sets the show `unavailable` BEFORE deleting a single object, so
     *   a delete that fails midway leaves an UNPUBLISHED show with some dead
     *   audio — not the show as it was. Calling delete again finishes the job.
     *   The ordering is deliberate: the failure that is possible is a show still
     *   listed but broken, never one that is gone but still published.
     * - Afterwards the feed 404s rather than answering `410 Gone`, because no row
     *   survives to answer from — so a podcast client stops eventually rather than
     *   at once, and episodes already downloaded to a device stay there.
     *
     * Refused (`403`) for a show you do not own and for an RSS-mirrored one, which
     * belongs to the catalogue and to nobody; `409` for a show under a platform
     * takedown, whose record a creator does not get to erase.
     */
    deletePodcast(podcastId: string): Promise<PodcastDeleted>;
    /**
     * `DELETE /api/episodes/:id` — permanently delete one episode of a Syra-hosted
     * show you own.
     *
     * IRREVERSIBLE. Its row goes with its HLS ladder, transcript, credits, AES
     * key, any outstanding ingest ticket and every listener's saved position in
     * it; its audio is swept from the episode's own `hls/{showId}/{episodeId}/`
     * directory plus the keys the row records. The parent show's `episodeCount`
     * and `lastEpisodeAt` are recomputed in the same transaction.
     *
     * `unpublishEpisode` is the reversible half of this space, and it is not
     * exposed here — reach for {@link SyraClient.updatePodcast} territory only if
     * you want the episode BACK later. This one does not come back.
     *
     * Refused exactly as {@link SyraClient.deletePodcast} is: `403` for an episode
     * on a show you do not own or that is not Syra-hosted, `409` when the show is
     * under a platform takedown.
     */
    deleteEpisode(episodeId: string): Promise<EpisodeDeleted>;
    /**
     * `POST /api/podcasts/:id/episodes/draft` — reserve an episode now and get a
     * single-use ticket to attach its audio later, from a process with no session.
     *
     * The returned ticket is a bearer capability with a deadline: it is good for
     * ONE redemption against THIS episode, and it stops working if the show
     * changes hands. Treat it as a secret.
     */
    createEpisodeDraft(podcastId: string, input: CreateEpisodeDraftInput): Promise<EpisodeDraft>;
    /**
     * `POST /api/podcasts/episodes/:id/ingest` — redeem a draft's ticket by
     * attaching the audio.
     *
     * Takes the whole {@link EpisodeDraft} rather than a loose id and token, so the
     * two cannot be paired up wrongly by a caller holding several drafts.
     *
     * Authenticated by the TICKET, not by the session — this is the one method here
     * that works with no `getAccessToken` at all, which is the entire point of it.
     */
    ingestEpisode(draft: Pick<EpisodeDraft, 'episodeId' | 'ingestTicket'>, audio: UploadPayload, input?: IngestEpisodeInput, filename?: string): Promise<EpisodeSummary>;
    /**
     * `POST /api/podcasts/episodes/:id/ingest/abandon` — redeem a draft's ticket
     * by giving the reservation up.
     *
     * The other ending of {@link SyraClient.ingestEpisode}, and the one a
     * generation pipeline needs when it fails on its own side. Call it and the
     * episode becomes `failed`; do not call it and the episode sits at
     * `processing` with no audio forever, because Syra has no way to learn that
     * the audio is never coming.
     *
     * It spends the SAME single use — a ticket buys one outcome, not two — so a
     * worker that abandons an episode cannot afterwards ingest it, and vice versa.
     *
     * `reason` is for the Syra operator log and is capped at 200 characters. It is
     * never stored on the episode and never returned, so do not pass an upstream
     * provider's raw error: send a short description of what your pipeline did.
     *
     * Authenticated by the TICKET, not by the session, exactly as
     * {@link SyraClient.ingestEpisode} is.
     */
    abandonEpisodeIngest(draft: Pick<EpisodeDraft, 'episodeId' | 'ingestTicket'>, reason?: string): Promise<EpisodeSummary>;
    /**
     * `GET /api/podcasts/episodes/:id/stream` — a tokenized HLS URL for a
     * Syra-hosted episode. Requires a session: the URL it returns embeds a stream
     * token minted for the caller.
     */
    getEpisodeStream(episodeId: string): Promise<EpisodeStream>;
}
/**
 * Create a headless client for the public Syra API. Public reads only — there
 * is no authentication in this version.
 */
export declare function createSyraClient(options?: SyraClientOptions): SyraClient;
//# sourceMappingURL=client.d.ts.map