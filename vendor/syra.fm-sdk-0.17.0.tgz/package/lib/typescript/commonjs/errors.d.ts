import type { PublicApiErrorCode } from '@syra.fm/contracts';
/**
 * Error thrown when the Syra API returns a non-2xx response.
 */
export declare class SyraApiError extends Error {
    /** HTTP status code returned by the API. */
    readonly status: number;
    readonly code?: PublicApiErrorCode;
    constructor(status: number, message: string, code?: PublicApiErrorCode);
}
//# sourceMappingURL=errors.d.ts.map