import { z } from 'zod';
/**
 * One podcast episode queued behind the current stream. `episodeId` is the
 * opaque Syra episode handle; `syraPodcastId` (when present) identifies its show.
 * The playable audio URL is never carried here — it is resolved server-side at
 * play-time.
 */
export declare const ZPodcastQueueItem: z.ZodObject<{
    syraPodcastId: z.ZodOptional<z.ZodString>;
    episodeId: z.ZodString;
}, z.core.$loose>;
export type PodcastQueueItem = z.infer<typeof ZPodcastQueueItem>;
export declare const ZRoom: z.ZodPreprocess<z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    ownerType: z.ZodDefault<z.ZodEnum<{
        profile: "profile";
        house: "house";
        agora: "agora";
    }>>;
    host: z.ZodString;
    houseId: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    createdByAdmin: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    type: z.ZodDefault<z.ZodEnum<{
        talk: "talk";
        stage: "stage";
        broadcast: "broadcast";
    }>>;
    broadcastKind: z.ZodNullable<z.ZodOptional<z.ZodEnum<{
        agora: "agora";
        user: "user";
    }>>>;
    status: z.ZodEnum<{
        scheduled: "scheduled";
        live: "live";
        ended: "ended";
    }>;
    scheduledStart: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    startedAt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    endedAt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    speakerPermission: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        everyone: "everyone";
        followers: "followers";
        invited: "invited";
    }>>>;
    participants: z.ZodDefault<z.ZodArray<z.ZodString>>;
    speakers: z.ZodDefault<z.ZodArray<z.ZodString>>;
    maxParticipants: z.ZodDefault<z.ZodNumber>;
    topic: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    archived: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    seriesId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    stats: z.ZodOptional<z.ZodObject<{
        peakListeners: z.ZodNumber;
        totalJoined: z.ZodNumber;
    }, z.core.$strip>>;
    activeIngressId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    activeStreamUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    streamTitle: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    streamImage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    streamDescription: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    rtmpUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    rtmpStreamKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    streamStartedAt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    streamDurationSec: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    podcastQueue: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        syraPodcastId: z.ZodOptional<z.ZodString>;
        episodeId: z.ZodString;
    }, z.core.$loose>>>>;
    recordingEnabled: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    recordingEgressId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    createdAt: z.ZodString;
}, z.core.$loose>, unknown>;
export type Room = z.infer<typeof ZRoom>;
export declare const ZRoomParticipant: z.ZodObject<{
    userId: z.ZodString;
    role: z.ZodEnum<{
        host: "host";
        speaker: "speaker";
        listener: "listener";
    }>;
    isMuted: z.ZodBoolean;
    joinedAt: z.ZodString;
}, z.core.$loose>;
export type RoomParticipant = z.infer<typeof ZRoomParticipant>;
export declare const ZHouseMember: z.ZodObject<{
    userId: z.ZodString;
    role: z.ZodEnum<{
        host: "host";
        owner: "owner";
        admin: "admin";
        member: "member";
    }>;
    joinedAt: z.ZodString;
}, z.core.$loose>;
export type HouseMember = z.infer<typeof ZHouseMember>;
/**
 * House visibility as three orthogonal axes — mirrors the backend `House`
 * model. `discovery` (who can find it), `rooms` (who can see/enter its rooms),
 * `join` (how one becomes a member). See the backend model for the full
 * contract.
 */
export declare const ZHouseVisibility: z.ZodObject<{
    discovery: z.ZodDefault<z.ZodEnum<{
        unlisted: "unlisted";
        listed: "listed";
        hidden: "hidden";
    }>>;
    rooms: z.ZodDefault<z.ZodEnum<{
        anyone: "anyone";
        members: "members";
    }>>;
    join: z.ZodDefault<z.ZodEnum<{
        anyone: "anyone";
        invite: "invite";
    }>>;
}, z.core.$loose>;
export type HouseVisibility = z.infer<typeof ZHouseVisibility>;
export declare const ZHouse: z.ZodPreprocess<z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    avatar: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    coverImage: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    members: z.ZodDefault<z.ZodArray<z.ZodObject<{
        userId: z.ZodString;
        role: z.ZodEnum<{
            host: "host";
            owner: "owner";
            admin: "admin";
            member: "member";
        }>;
        joinedAt: z.ZodString;
    }, z.core.$loose>>>;
    memberCount: z.ZodOptional<z.ZodNumber>;
    createdBy: z.ZodString;
    visibility: z.ZodDefault<z.ZodObject<{
        discovery: z.ZodDefault<z.ZodEnum<{
            unlisted: "unlisted";
            listed: "listed";
            hidden: "hidden";
        }>>;
        rooms: z.ZodDefault<z.ZodEnum<{
            anyone: "anyone";
            members: "members";
        }>>;
        join: z.ZodDefault<z.ZodEnum<{
            anyone: "anyone";
            invite: "invite";
        }>>;
    }, z.core.$loose>>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    createdAt: z.ZodString;
}, z.core.$loose>, unknown>;
export type House = z.infer<typeof ZHouse>;
export declare const ZRecurrence: z.ZodObject<{
    type: z.ZodEnum<{
        daily: "daily";
        weekly: "weekly";
        biweekly: "biweekly";
        monthly: "monthly";
    }>;
    dayOfWeek: z.ZodOptional<z.ZodNumber>;
    dayOfMonth: z.ZodOptional<z.ZodNumber>;
    time: z.ZodString;
    timezone: z.ZodDefault<z.ZodString>;
}, z.core.$loose>;
export type Recurrence = z.infer<typeof ZRecurrence>;
export declare const ZRoomTemplate: z.ZodObject<{
    titlePattern: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<{
        talk: "talk";
        stage: "stage";
        broadcast: "broadcast";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    maxParticipants: z.ZodDefault<z.ZodNumber>;
    speakerPermission: z.ZodDefault<z.ZodEnum<{
        everyone: "everyone";
        followers: "followers";
        invited: "invited";
    }>>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$loose>;
export type RoomTemplate = z.infer<typeof ZRoomTemplate>;
export declare const ZSeriesEpisode: z.ZodObject<{
    roomId: z.ZodString;
    scheduledStart: z.ZodString;
    episodeNumber: z.ZodNumber;
}, z.core.$loose>;
export type SeriesEpisode = z.infer<typeof ZSeriesEpisode>;
export declare const ZSeries: z.ZodPreprocess<z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    coverImage: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    houseId: z.ZodNullable<z.ZodOptional<z.ZodString>>;
    createdBy: z.ZodString;
    recurrence: z.ZodObject<{
        type: z.ZodEnum<{
            daily: "daily";
            weekly: "weekly";
            biweekly: "biweekly";
            monthly: "monthly";
        }>;
        dayOfWeek: z.ZodOptional<z.ZodNumber>;
        dayOfMonth: z.ZodOptional<z.ZodNumber>;
        time: z.ZodString;
        timezone: z.ZodDefault<z.ZodString>;
    }, z.core.$loose>;
    roomTemplate: z.ZodObject<{
        titlePattern: z.ZodString;
        type: z.ZodDefault<z.ZodEnum<{
            talk: "talk";
            stage: "stage";
            broadcast: "broadcast";
        }>>;
        description: z.ZodOptional<z.ZodString>;
        maxParticipants: z.ZodDefault<z.ZodNumber>;
        speakerPermission: z.ZodDefault<z.ZodEnum<{
            everyone: "everyone";
            followers: "followers";
            invited: "invited";
        }>>;
        tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$loose>;
    episodes: z.ZodDefault<z.ZodArray<z.ZodObject<{
        roomId: z.ZodString;
        scheduledStart: z.ZodString;
        episodeNumber: z.ZodNumber;
    }, z.core.$loose>>>;
    nextEpisodeNumber: z.ZodDefault<z.ZodNumber>;
    isActive: z.ZodDefault<z.ZodBoolean>;
    createdAt: z.ZodString;
}, z.core.$loose>, unknown>;
export type Series = z.infer<typeof ZSeries>;
export declare const ZRecording: z.ZodPreprocess<z.ZodObject<{
    id: z.ZodString;
    roomId: z.ZodString;
    roomTitle: z.ZodString;
    host: z.ZodString;
    status: z.ZodEnum<{
        ready: "ready";
        processing: "processing";
        failed: "failed";
        recording: "recording";
        deleted: "deleted";
    }>;
    egressId: z.ZodString;
    objectKey: z.ZodString;
    fileSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    durationMs: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    startedAt: z.ZodString;
    stoppedAt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    access: z.ZodDefault<z.ZodEnum<{
        public: "public";
        participants: "participants";
    }>>;
    participantIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    expiresAt: z.ZodString;
    createdAt: z.ZodString;
}, z.core.$loose>, unknown>;
export type Recording = z.infer<typeof ZRecording>;
export declare const ZStartStreamResponse: z.ZodObject<{
    ingressId: z.ZodString;
    url: z.ZodString;
}, z.core.$loose>;
export declare const ZGenerateStreamKeyResponse: z.ZodObject<{
    rtmpUrl: z.ZodString;
    streamKey: z.ZodString;
}, z.core.$loose>;
export declare const ZStreamInfo: z.ZodObject<{
    title: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
export type StreamInfo = z.infer<typeof ZStreamInfo>;
export declare const ZRoomAttachment: z.ZodObject<{
    roomId: z.ZodString;
    title: z.ZodString;
    status: z.ZodOptional<z.ZodEnum<{
        scheduled: "scheduled";
        live: "live";
        ended: "ended";
    }>>;
    type: z.ZodOptional<z.ZodEnum<{
        talk: "talk";
        stage: "stage";
        broadcast: "broadcast";
    }>>;
    topic: z.ZodOptional<z.ZodString>;
    host: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
export type RoomAttachment = z.infer<typeof ZRoomAttachment>;
export declare function validateRoom(data: unknown): Room | null;
export declare function validateRooms(items: unknown[]): Room[];
export declare function validateHouse(data: unknown): House | null;
export declare function validateRecording(data: unknown): Recording | null;
export declare function validateRecordings(items: unknown[]): Recording[];
export declare function validateSeries(data: unknown): Series | null;
//# sourceMappingURL=validation.d.ts.map