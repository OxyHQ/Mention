import type { Room, Recording, House, HouseVisibility, HttpClient } from '../types';
export interface CreateRoomData {
    [key: string]: unknown;
    title: string;
    description?: string;
    topic?: string;
    scheduledStart?: string;
    speakerPermission?: 'everyone' | 'followers' | 'invited';
    type?: 'talk' | 'stage' | 'broadcast';
    ownerType?: 'profile' | 'house';
    houseId?: string;
    broadcastKind?: 'user';
    recordingEnabled?: boolean;
}
export interface StreamMetadataUpdate extends Record<string, unknown> {
    url?: string;
    title?: string;
    image?: string;
    description?: string;
}
/** A Syra podcast show, as proxied by Mention `GET /profile/media/search?type=podcast`. */
export interface PodcastResult {
    syraPodcastId: string;
    title: string;
    author?: string;
    artworkUrl?: string;
}
/**
 * A single episode row for the picker. Deliberately carries NO audio URL — the
 * enclosure stays server-owned and is resolved at stream-start by the backend.
 */
export interface EpisodeListItem {
    episodeId: string;
    title: string;
    durationSec?: number;
    publishedAt?: string;
    artworkUrl?: string;
}
/**
 * A single Syra music track row for the listening-party picker. Like the podcast
 * rows it carries NO audio URL — the playable source (presigned original /
 * tokenized HLS) stays server-owned and is resolved at stream-start by the
 * backend from the opaque `trackId` alone.
 */
export interface MusicTrackResult {
    trackId: string;
    title: string;
    artist?: string;
    durationSec?: number;
    artworkUrl?: string;
}
/** Optional seed to start a track stream: a single track, an album, or a playlist. */
export interface StartTrackStreamBody extends Record<string, unknown> {
    trackId?: string;
    albumId?: string;
    playlistId?: string;
    /** Tracks to queue AFTER `trackId` (up-next). Only used with `trackId`. */
    queue?: {
        trackId: string;
    }[];
}
/**
 * The outcome of a podcast catalog fetch. `ok:false` signals a genuine request
 * failure (network/transport error), letting the picker distinguish it from a
 * successful-but-empty result (`ok:true` with `items: []`). Neither
 * `searchPodcasts` nor `getPodcastEpisodes` throws — a failure resolves to
 * `{ ok:false }`.
 */
export type PodcastFetchResult<T> = {
    ok: true;
    items: T[];
    hasMore: boolean;
    offset: number;
} | {
    ok: false;
};
export declare function createRoomsService(httpClient: HttpClient): {
    getRooms(status?: string, type?: string): Promise<Room[]>;
    getRoom(id: string): Promise<Room | null>;
    createRoom(data: CreateRoomData): Promise<Room | null>;
    startRoom(id: string): Promise<boolean>;
    endRoom(id: string): Promise<boolean>;
    stopRoom(id: string): Promise<boolean>;
    joinRoom(id: string): Promise<boolean>;
    leaveRoom(id: string): Promise<boolean>;
    startStream(id: string, data: {
        url: string;
        title?: string;
        image?: string;
        description?: string;
    }): Promise<{
        ingressId: string;
        url: string;
    } | null>;
    generateStreamKey(id: string, data?: {
        title?: string;
        image?: string;
        description?: string;
    }): Promise<{
        rtmpUrl: string;
        streamKey: string;
    } | null>;
    updateStreamMetadata(id: string, data: StreamMetadataUpdate): Promise<boolean>;
    stopStream(id: string): Promise<boolean>;
    searchPodcasts(query: string, offset?: number): Promise<PodcastFetchResult<PodcastResult>>;
    getPodcastEpisodes(syraPodcastId: string, offset?: number): Promise<PodcastFetchResult<EpisodeListItem>>;
    startPodcastStream(roomId: string, body: {
        syraPodcastId: string;
        episodeId: string;
        queue?: {
            syraPodcastId?: string;
            episodeId: string;
        }[];
    }): Promise<{
        ingressId: string;
        url: string;
    } | null>;
    /**
     * Advance a live podcast stream to the next queued episode (manager + live
     * gated server-side). Resolves `{ ended: false }` when the next episode
     * started, `{ ended: true }` when the queue drained (the stream will clear
     * via the `room:stream:stopped` socket event), or `null` on failure.
     */
    skipPodcastNext(roomId: string): Promise<{
        ended: boolean;
    } | null>;
    /**
     * Search the Syra music catalog for the listening-party picker. Reuses the
     * existing tracks search endpoint (`GET /tracks/search`); like the podcast
     * search it never throws — a failure resolves to `{ ok:false }` so the picker
     * can tell a genuine error from a successful-but-empty result.
     */
    searchMusic(query: string, offset?: number): Promise<PodcastFetchResult<MusicTrackResult>>;
    /**
     * Start streaming Syra music into the room (a "listening party"): a single
     * track (optionally with an up-next `queue`), or an album / playlist whose
     * ordered tracks the backend resolves into the queue. The client sends only
     * ids — the playable audio URL is resolved server-side at stream-start.
     */
    startTrackStream(roomId: string, body: StartTrackStreamBody): Promise<{
        ingressId: string;
        url: string;
    } | null>;
    deleteRoom(id: string): Promise<boolean>;
    archiveRoom(id: string): Promise<{
        success: boolean;
        archived: boolean;
    }>;
    getHouses(search?: string): Promise<House[]>;
    getHouse(id: string): Promise<House | null>;
    getMyHouses(userId: string): Promise<House[]>;
    getUserHouses(userId: string): Promise<House[]>;
    getHouseRooms(houseId: string, status?: string): Promise<Room[]>;
    startRecording(roomId: string): Promise<boolean>;
    stopRecording(roomId: string): Promise<boolean>;
    getRoomRecordings(roomId: string): Promise<Recording[]>;
    getRecording(recordingId: string): Promise<{
        recording: Recording;
        playbackUrl: string;
    } | null>;
    updateRecordingAccess(recordingId: string, access: "public" | "participants"): Promise<boolean>;
    deleteRecording(recordingId: string): Promise<boolean>;
    getRecordings(sortBy?: string, limit?: number): Promise<Recording[]>;
    getTopHosts(): Promise<{
        userId: string;
        roomCount: number;
        totalListeners: number;
    }[]>;
    createHouse(data: {
        name: string;
        description?: string;
        tags?: string[];
        visibility?: Partial<HouseVisibility>;
    }): Promise<House | null>;
    uploadHouseAvatar(houseId: string, formData: FormData): Promise<string | null>;
    uploadHouseCover(houseId: string, formData: FormData): Promise<string | null>;
    uploadRoomImage(roomId: string, formData: FormData): Promise<string | null>;
    uploadSeriesCover(seriesId: string, formData: FormData): Promise<string | null>;
};
export type RoomsServiceInstance = ReturnType<typeof createRoomsService>;
//# sourceMappingURL=spacesService.d.ts.map