import type { HttpClient } from '../types';
export type GetRoomTokenFn = (roomId: string) => Promise<{
    token: string;
    url: string;
}>;
export declare function createGetRoomToken(httpClient: Pick<HttpClient, 'post'>): GetRoomTokenFn;
//# sourceMappingURL=livekitService.d.ts.map