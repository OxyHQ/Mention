import type { RoomParticipant, ParticipantsUpdateData, MuteUpdateData, SpeakerRequestData } from '../types';
type SimpleRoomCallback = (data: {
    roomId: string;
    timestamp?: string;
}) => void;
export declare class RoomSocketService {
    private socket;
    private _isConnected;
    private socketUrl;
    constructor(socketUrl: string);
    get isConnected(): boolean;
    connect(userId: string, token?: string): void;
    disconnect(): void;
    joinRoom(roomId: string, callback?: (res: {
        success: boolean;
        participants?: RoomParticipant[];
        myRole?: string;
        error?: string;
    }) => void): void;
    leaveRoom(roomId: string): void;
    setMute(roomId: string, isMuted: boolean): void;
    requestToSpeak(roomId: string): void;
    approveSpeaker(roomId: string, targetUserId: string): void;
    denySpeaker(roomId: string, targetUserId: string): void;
    removeSpeaker(roomId: string, targetUserId: string): void;
    onParticipantsUpdate(cb: (data: ParticipantsUpdateData) => void): () => void;
    onParticipantMute(cb: (data: MuteUpdateData) => void): () => void;
    onSpeakerRequestReceived(cb: (data: SpeakerRequestData) => void): () => void;
    onSpeakerApproved(cb: SimpleRoomCallback): () => void;
    onSpeakerDenied(cb: SimpleRoomCallback): () => void;
    onSpeakerRemoved(cb: SimpleRoomCallback): () => void;
    onRoomStarted(cb: SimpleRoomCallback): () => void;
    onRoomEnded(cb: SimpleRoomCallback): () => void;
    onUserJoined(cb: (data: {
        userId: string;
        role: string;
        roomId: string;
    }) => void): () => void;
    onUserLeft(cb: (data: {
        userId: string;
        roomId: string;
    }) => void): () => void;
    onStreamStarted(cb: (data: {
        roomId: string;
        title?: string;
        image?: string;
        description?: string;
        startedAt?: string;
        durationSec?: number;
        timestamp: string;
    }) => void): () => void;
    onStreamStopped(cb: (data: {
        roomId: string;
        timestamp: string;
    }) => void): () => void;
    onRecordingStarted(cb: (data: {
        roomId: string;
        recordingId: string;
        timestamp: string;
    }) => void): () => void;
    onRecordingStopped(cb: (data: {
        roomId: string;
        recordingId?: string;
        reason?: string;
        timestamp: string;
    }) => void): () => void;
}
export {};
//# sourceMappingURL=spaceSocketService.d.ts.map