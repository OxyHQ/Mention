import React from 'react';
import { ViewStyle, type ColorValue } from 'react-native';
export declare const SyraIcon: ({ color, size, style, }: {
    color?: ColorValue;
    size?: number;
    style?: ViewStyle;
}) => React.JSX.Element;
export declare const SyraIconActive: ({ color, size, style, }: {
    color?: ColorValue;
    size?: number;
    style?: ViewStyle;
}) => React.JSX.Element;
//# sourceMappingURL=syra-icon.d.ts.map