import React from 'react';
import { ViewStyle, type ColorValue } from 'react-native';
export declare const LiveRoomsIcon: ({ color, size, style, }: {
    color?: ColorValue;
    size?: number;
    style?: ViewStyle;
}) => React.JSX.Element;
export declare const LiveRoomsIconActive: ({ color, size, style, }: {
    color?: ColorValue;
    size?: number;
    style?: ViewStyle;
}) => React.JSX.Element;
//# sourceMappingURL=spaces-icon.d.ts.map