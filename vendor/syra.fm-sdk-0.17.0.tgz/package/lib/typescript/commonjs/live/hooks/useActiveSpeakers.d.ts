import { Room } from 'livekit-client';
export declare function useActiveSpeakers(room: Room | null): Set<string>;
//# sourceMappingURL=useActiveSpeakers.d.ts.map