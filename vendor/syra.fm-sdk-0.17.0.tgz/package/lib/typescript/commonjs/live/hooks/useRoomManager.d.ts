import type { RoomAttachmentData } from '../types';
export declare const useRoomManager: () => {
    room: RoomAttachmentData | null;
    setRoom: import("react").Dispatch<import("react").SetStateAction<RoomAttachmentData | null>>;
    attachRoom: (data: RoomAttachmentData) => void;
    removeRoom: () => void;
    hasContent: () => boolean;
    loadRoomFromDraft: (draftRoom: RoomAttachmentData | null) => void;
    clearRoom: () => void;
};
//# sourceMappingURL=useRoomManager.d.ts.map