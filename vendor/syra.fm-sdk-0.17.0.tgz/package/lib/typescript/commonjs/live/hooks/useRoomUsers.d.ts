import type { UserEntity } from '../types';
export declare function useRoomUsers(userIds: string[]): void;
export declare function getDisplayName(userProfile: UserEntity | undefined, userId: string, isCurrentUser?: boolean): string;
export declare function getAvatarUrl(userProfile: UserEntity | undefined, oxyServices: unknown, getCachedFileDownloadUrlSync: (oxyServices: unknown, fileId: string, variant?: string) => string): string | undefined;
//# sourceMappingURL=useRoomUsers.d.ts.map