import { Room } from 'livekit-client';
interface UseRoomAudioOptions {
    roomId: string;
    isSpeaker: boolean;
    isMuted: boolean;
    isConnected: boolean;
}
interface UseRoomAudioReturn {
    isLiveKitConnected: boolean;
    localAudioEnabled: boolean;
    micPermissionDenied: boolean;
    livekitRoom: Room | null;
}
export declare function useRoomAudio({ roomId, isSpeaker, isMuted, isConnected, }: UseRoomAudioOptions): UseRoomAudioReturn;
export {};
//# sourceMappingURL=useRoomAudio.d.ts.map