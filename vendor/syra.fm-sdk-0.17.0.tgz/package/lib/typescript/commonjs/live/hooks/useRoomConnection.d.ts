import type { RoomParticipant, StreamInfo } from '../types';
interface UseRoomConnectionOptions {
    roomId: string;
    enabled?: boolean;
}
interface UseRoomConnectionReturn {
    isConnected: boolean;
    participants: RoomParticipant[];
    myRole: 'host' | 'speaker' | 'listener' | null;
    isMuted: boolean;
    speakerRequests: Array<{
        userId: string;
        requestedAt: string;
    }>;
    activeStream: StreamInfo | null;
    isRecording: boolean;
    activeRecordingId: string | null;
    join: () => void;
    leave: () => void;
    toggleMute: () => void;
    requestToSpeak: () => void;
    approveSpeaker: (userId: string) => void;
    denySpeaker: (userId: string) => void;
    removeSpeaker: (userId: string) => void;
    isRoomEnded: boolean;
}
export declare function useRoomConnection({ roomId, enabled, }: UseRoomConnectionOptions): UseRoomConnectionReturn;
export {};
//# sourceMappingURL=useRoomConnection.d.ts.map