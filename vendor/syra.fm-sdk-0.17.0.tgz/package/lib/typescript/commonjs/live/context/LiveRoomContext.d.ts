import React from 'react';
interface LiveRoomContextProps {
    activeRoomId: string | null;
    joinLiveRoom: (roomId: string) => void;
    leaveLiveRoom: () => void;
}
export declare function useLiveRoom(): LiveRoomContextProps;
export declare function LiveRoomProvider({ children }: {
    children: React.ReactNode;
}): React.JSX.Element;
export {};
//# sourceMappingURL=LiveRoomContext.d.ts.map