import React from 'react';
interface MiniRoomBarProps {
    title: string;
    participantCount: number;
    isMuted: boolean;
    canSpeak: boolean;
    activeSpeakerCount?: number;
    onExpand: () => void;
    onToggleMute: () => void;
    onLeave: () => void;
}
export declare const MINI_BAR_HEIGHT = 64;
export declare function MiniRoomBar({ title, participantCount, isMuted, canSpeak, activeSpeakerCount, onExpand, onToggleMute, onLeave, }: MiniRoomBarProps): React.JSX.Element;
export {};
//# sourceMappingURL=MiniRoomBar.d.ts.map