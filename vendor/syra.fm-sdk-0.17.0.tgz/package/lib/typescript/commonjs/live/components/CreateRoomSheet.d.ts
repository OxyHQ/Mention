import React from 'react';
import type { Room, House } from '../types';
/**
 * Failure copy the sheet shows INLINE. It used to go to the host `toast`, but
 * the sheet is usually presented in a native modal window, and a toast renders
 * in the main window underneath it: a failed create (a 401 from an expired
 * session, a network drop) looked like a button that did nothing.
 */
export declare const CREATE_ROOM_ERRORS: {
    readonly createFailed: "Couldn't create the room. Check your connection and that you're signed in, then try again.";
    readonly scheduleMissing: "Enter a scheduled start time to schedule the room.";
};
export interface CreateRoomSheetRef {
    handleCreateAndStart: () => void;
    handleSchedule: () => void;
    handleCreateForEmbed: () => void;
}
export interface CreateRoomFormState {
    isValid: boolean;
    loading: boolean;
    hasScheduledStart: boolean;
}
interface CreateRoomSheetProps {
    onClose: () => void;
    onRoomCreated?: (room: Room) => void;
    mode?: 'standalone' | 'embed';
    ScrollViewComponent?: React.ComponentType<{
        children: React.ReactNode;
    }>;
    hideFooter?: boolean;
    onFormStateChange?: (state: CreateRoomFormState) => void;
    houses?: House[];
}
export declare const CreateRoomSheet: React.ForwardRefExoticComponent<CreateRoomSheetProps & React.RefAttributes<CreateRoomSheetRef>>;
export default CreateRoomSheet;
//# sourceMappingURL=CreateRoomSheet.d.ts.map