import React from 'react';
/** One episode selected for the up-next queue. The show id is always known here. */
export interface PodcastQueueSelection {
    syraPodcastId: string;
    episodeId: string;
}
interface PodcastStreamPickerProps {
    onSelectEpisode: (syraPodcastId: string, episodeId: string) => void;
    /**
     * Start a multi-episode session: the first item plays immediately, the rest
     * become the room's up-next queue. Optional — hosts that omit it get the
     * single-tap "play this now" flow only, and the queue affordances (per-row "+"
     * and the footer) are hidden.
     */
    onStartQueue?: (items: PodcastQueueSelection[]) => void;
}
/**
 * Self-contained two-level podcast picker for the live-room stream setup. Level 1
 * is a debounced Syra show search; tapping a show drills into Level 2, its episode
 * list. Tapping an episode reports `(syraPodcastId, episodeId)` to the parent — the
 * picker owns NO room/stream logic. Ships inside @syra.fm/sdk, so it depends only
 * on `useLiveConfig()` injection and never imports from a host app (`@/`).
 *
 * UX affordances (all backend-field-free): a host copyright disclaimer, an honest
 * error+Retry state distinct from empty results, a one-tap "stream my pinned
 * podcast" quick-start row (when the host exposes `getPinnedPodcast`), and an
 * "Open in Syra" deep link on the episode-list header.
 */
export declare function PodcastStreamPicker({ onSelectEpisode, onStartQueue }: PodcastStreamPickerProps): React.JSX.Element;
interface MusicPickerProps {
    /** Stream a single track immediately. */
    onSelectTrack: (trackId: string) => void;
    /**
     * Start a multi-track session: the first track plays immediately, the rest
     * become the room's up-next queue. Optional — hosts that omit it get the
     * single-tap "play this now" flow only, and the queue affordances are hidden.
     */
    onStartQueue?: (trackIds: string[]) => void;
}
/**
 * Self-contained single-level music picker for the live-room "listening party".
 * A debounced Syra catalog search; tapping a track reports its `trackId` to the
 * parent (the picker owns NO room/stream logic and never sees an audio URL — the
 * backend resolves the playable source server-side). Ships inside the shared
 * package, so it depends only on `useLiveConfig()` injection and never imports
 * from a host app (`@/`).
 *
 * Mirrors {@link PodcastStreamPicker}: a host copyright/broadcast disclaimer, an
 * honest error+Retry state distinct from empty results, and an optional up-next
 * queue (per-row "+" plus a floating "Play (N)" footer).
 */
export declare function MusicPicker({ onSelectTrack, onStartQueue }: MusicPickerProps): React.JSX.Element;
export {};
//# sourceMappingURL=PodcastStreamPicker.d.ts.map