import React from 'react';
interface StreamConfigModalProps {
    visible: boolean;
    onClose: () => void;
    roomId: string;
    initialStreamUrl?: string;
    onStreamStarted: () => void;
}
export declare function StreamConfigModal({ visible, onClose, roomId, initialStreamUrl, onStreamStarted, }: StreamConfigModalProps): React.JSX.Element;
export {};
//# sourceMappingURL=StreamConfigModal.d.ts.map