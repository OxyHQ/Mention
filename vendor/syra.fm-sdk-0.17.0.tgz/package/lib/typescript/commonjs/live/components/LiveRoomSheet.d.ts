import React from 'react';
interface LiveRoomSheetProps {
    roomId: string;
    isExpanded: boolean;
    onCollapse: () => void;
    onExpand: () => void;
    onLeave: () => void;
}
export declare function LiveRoomSheet({ roomId, isExpanded, onCollapse, onExpand, onLeave, }: LiveRoomSheetProps): React.JSX.Element;
export {};
//# sourceMappingURL=LiveRoomSheet.d.ts.map