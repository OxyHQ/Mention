import React from 'react';
interface StreamConfigPanelProps {
    roomId: string;
    roomStatus?: string;
    initialStreamUrl?: string;
    initialRtmpUrl?: string;
    initialStreamKey?: string;
    onClose: () => void;
    onStreamStarted: () => void;
}
export declare function StreamConfigPanel({ roomId, roomStatus, initialStreamUrl, initialRtmpUrl, initialStreamKey, onClose, onStreamStarted, }: StreamConfigPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=StreamConfigPanel.d.ts.map