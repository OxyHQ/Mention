import React from 'react';
interface AnimatedPulseProps {
    size?: number;
    color?: string;
}
export declare const AnimatedPulse: React.NamedExoticComponent<AnimatedPulseProps>;
export {};
//# sourceMappingURL=AnimatedPulse.d.ts.map