import React from 'react';
import type { Room, RoomParticipant, LiveTheme } from '../types';
interface InsightsPanelProps {
    room: Room | null;
    participants: RoomParticipant[];
    theme: LiveTheme;
    onClose: () => void;
}
export declare function InsightsPanel({ room, participants, theme, onClose }: InsightsPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=InsightsPanel.d.ts.map