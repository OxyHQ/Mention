import React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
interface RoomCardProps {
    room: {
        id: string;
        title: string;
        status: 'scheduled' | 'live' | 'ended';
        type?: 'talk' | 'stage' | 'broadcast';
        topic?: string | null;
        participants?: string[];
        speakers?: string[];
        host: string;
        houseId?: string | null;
        scheduledStart?: string | null;
        startedAt?: string | null;
        endedAt?: string | null;
        createdAt?: string;
        stats?: {
            peakListeners?: number;
            totalJoined?: number;
        };
    };
    onPress?: () => void;
    variant?: 'default' | 'compact';
    house?: {
        name: string;
        avatarUrl?: string;
    } | null;
    hostName?: string;
    hostAvatarUri?: string;
    onMenuPress?: () => void;
    onSave?: () => void;
    isSaved?: boolean;
    style?: StyleProp<ViewStyle>;
}
/**
 * A room in a list. The `default` variant renders ONE of two presentations,
 * selected by `room.status`, because a live room and a listing of one are
 * different objects:
 *
 * - **live** → a featured card: the LIVE chip + the listener count (the only
 *   number that matters while a room is on air), the speaker faces, the host,
 *   and an explicit Join CTA.
 * - **scheduled / ended** → a flush full-width row: host avatar, title + when,
 *   byline, and one subtle right-side action. No card chrome, no CTA — there is
 *   nothing to join yet (or ever again).
 *
 * At most ONE status chip is ever shown (a live room is not a scheduled one, and
 * the date already says "scheduled"); the room type carries no badge at all.
 *
 * The `compact` variant is the small fixed-width card used by post attachments
 * and the composer preview, and follows the same rules in miniature.
 */
export declare const RoomCard: React.FC<RoomCardProps>;
export default RoomCard;
//# sourceMappingURL=RoomCard.d.ts.map