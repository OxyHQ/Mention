import React from 'react';
import type { Recording, LiveTheme } from '../types';
interface RecordingsPanelProps {
    roomId: string;
    isHost: boolean;
    theme: LiveTheme;
    onClose: () => void;
    onPlay?: (playbackUrl: string, recording: Recording) => void;
}
export declare function RecordingsPanel({ roomId, isHost, theme, onClose, onPlay }: RecordingsPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=RecordingsPanel.d.ts.map