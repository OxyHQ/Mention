import React from 'react';
interface AnimatedSpeakerRingProps {
    isSpeaking: boolean;
    isMuted: boolean;
    primaryColor: string;
    children: React.ReactNode;
}
export declare const AnimatedSpeakerRing: React.NamedExoticComponent<AnimatedSpeakerRingProps>;
export {};
//# sourceMappingURL=AnimatedSpeakerRing.d.ts.map