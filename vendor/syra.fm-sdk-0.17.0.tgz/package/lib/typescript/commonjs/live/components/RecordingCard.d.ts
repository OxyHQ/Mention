import React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import type { Recording } from '../validation';
interface RecordingCardProps {
    recording: Recording;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}
export declare const RecordingCard: React.FC<RecordingCardProps>;
export default RecordingCard;
//# sourceMappingURL=RecordingCard.d.ts.map