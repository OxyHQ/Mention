import React from 'react';
import type { LiveTheme } from '../types';
interface PanelHeaderProps {
    title: string;
    theme: LiveTheme;
    onBack: () => void;
}
export declare function PanelHeader({ title, theme, onBack }: PanelHeaderProps): React.JSX.Element;
export {};
//# sourceMappingURL=PanelHeader.d.ts.map