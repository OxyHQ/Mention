import { z } from 'zod';

/**
 * Accept a payload whose identity arrives as `_id` and present it as `id`.
 *
 * `id` is REQUIRED on the four schemas below, which is correct against the current
 * backend — `_id` is not part of the wire contract. But the frontend deploys on its own path (`deploy-frontends.yml`, on `packages/frontend`
 * and `packages/shared-types`) while the backend deploy is gated, so a merge to
 * `main` can ship the client half ALONE. It did once: `GET /rooms` answered `_id`,
 * every room failed `ZRoom`, and `validateRooms` DROPS what it cannot parse — so
 * the Live screen went empty in production with only a `console.warn` to say so.
 *
 * Normalising here rather than teaching call sites to read `room.id ?? room._id`
 * is the architecture this repo already states: parse once at the API boundary and
 * return typed data. One place, no UI knows, and it is correct against an older
 * backend too — so no coordinated client flip is needed.
 *
 * It can be deleted once no deployed Syra backend serves `_id`. Nothing breaks if
 * it outlives that: a payload carrying only `id` passes through untouched.
 */
function withUnderscoreIdFallback<T extends z.ZodTypeAny>(schema: T) {
  return z.preprocess((value) => {
    if (value === null || typeof value !== 'object') return value;
    const doc = value as Record<string, unknown>;
    if (typeof doc['id'] === 'string' || typeof doc['_id'] !== 'string') return value;
    return { ...doc, id: doc['_id'] };
  }, schema);
}

// --- Podcast queue ---

/**
 * One podcast episode queued behind the current stream. `episodeId` is the
 * opaque Syra episode handle; `syraPodcastId` (when present) identifies its show.
 * The playable audio URL is never carried here — it is resolved server-side at
 * play-time.
 */
export const ZPodcastQueueItem = z
  .object({
    syraPodcastId: z.string().optional(),
    episodeId: z.string(),
  })
  .passthrough();

export type PodcastQueueItem = z.infer<typeof ZPodcastQueueItem>;

// --- Room (replaces Space) ---

export const ZRoom = withUnderscoreIdFallback(
  z
    .object({
      id: z.string(),
      title: z.string(),
      description: z.string().nullish(),

      // Ownership
      ownerType: z.enum(['profile', 'house', 'agora']).default('profile'),
      host: z.string(),
      houseId: z.string().optional().nullable(),
      createdByAdmin: z.string().optional().nullable(),

      // Classification
      type: z.enum(['talk', 'stage', 'broadcast']).default('talk'),
      broadcastKind: z.enum(['user', 'agora']).optional().nullable(),

      // Lifecycle
      status: z.enum(['scheduled', 'live', 'ended']),
      scheduledStart: z.string().nullish(),
      startedAt: z.string().nullish(),
      endedAt: z.string().nullish(),

      // Participation
      speakerPermission: z.enum(['everyone', 'followers', 'invited']).nullish(),
      participants: z.array(z.string()).default([]),
      speakers: z.array(z.string()).default([]),
      maxParticipants: z.number().default(100),

      // Content
      topic: z.string().nullish(),
      tags: z.array(z.string()).optional(),
      archived: z.boolean().optional().default(false),
      seriesId: z.string().nullish(),

      // Stats
      stats: z
        .object({
          peakListeners: z.number(),
          totalJoined: z.number(),
        })
        .optional(),

      // Streaming
      activeIngressId: z.string().nullish(),
      activeStreamUrl: z.string().nullish(),
      streamTitle: z.string().nullish(),
      streamImage: z.string().nullish(),
      streamDescription: z.string().nullish(),
      rtmpUrl: z.string().nullish(),
      rtmpStreamKey: z.string().nullish(),
      // Stream progress + podcast lifecycle (shared contract with the backend).
      // `streamStartedAt` is an ISO timestamp; `streamDurationSec` is the current
      // stream's total length in seconds when known (e.g. a podcast episode);
      // `podcastQueue` holds the episodes queued behind the current one.
      streamStartedAt: z.string().nullish(),
      streamDurationSec: z.number().nullish(),
      podcastQueue: z.array(ZPodcastQueueItem).nullish(),

      // Recording
      recordingEnabled: z.boolean().optional().default(true),
      recordingEgressId: z.string().nullish(),

      createdAt: z.string(),
    })
    .passthrough(),
);

export type Room = z.infer<typeof ZRoom>;

// --- Room Participant ---

export const ZRoomParticipant = z
  .object({
    userId: z.string(),
    role: z.enum(['host', 'speaker', 'listener']),
    isMuted: z.boolean(),
    joinedAt: z.string(),
  })
  .passthrough();

export type RoomParticipant = z.infer<typeof ZRoomParticipant>;

// --- House ---

export const ZHouseMember = z
  .object({
    userId: z.string(),
    role: z.enum(['owner', 'admin', 'host', 'member']),
    joinedAt: z.string(),
  })
  .passthrough();

export type HouseMember = z.infer<typeof ZHouseMember>;

/**
 * House visibility as three orthogonal axes — mirrors the backend `House`
 * model. `discovery` (who can find it), `rooms` (who can see/enter its rooms),
 * `join` (how one becomes a member). See the backend model for the full
 * contract.
 */
export const ZHouseVisibility = z
  .object({
    discovery: z.enum(['listed', 'unlisted', 'hidden']).default('listed'),
    rooms: z.enum(['anyone', 'members']).default('anyone'),
    join: z.enum(['anyone', 'invite']).default('invite'),
  })
  .passthrough();

export type HouseVisibility = z.infer<typeof ZHouseVisibility>;

export const ZHouse = withUnderscoreIdFallback(
  z
    .object({
      id: z.string(),
      name: z.string(),
      description: z.string().optional(),
      avatar: z.string().optional().nullable(),
      coverImage: z.string().optional().nullable(),
      // Withheld from non-members of a `rooms: members` house; `memberCount` is sent
      // in its place. Both survive `.passthrough()`.
      members: z.array(ZHouseMember).default([]),
      memberCount: z.number().optional(),
      createdBy: z.string(),
      visibility: ZHouseVisibility.default({
        discovery: 'listed',
        rooms: 'anyone',
        join: 'invite',
      }),
      tags: z.array(z.string()).optional(),
      createdAt: z.string(),
    })
    .passthrough(),
);

export type House = z.infer<typeof ZHouse>;

// --- Series ---

export const ZRecurrence = z
  .object({
    type: z.enum(['daily', 'weekly', 'biweekly', 'monthly']),
    dayOfWeek: z.number().min(0).max(6).optional(),
    dayOfMonth: z.number().min(1).max(31).optional(),
    time: z.string().regex(/^\d{2}:\d{2}$/),
    timezone: z.string().default('UTC'),
  })
  .passthrough();

export type Recurrence = z.infer<typeof ZRecurrence>;

export const ZRoomTemplate = z
  .object({
    titlePattern: z.string(),
    type: z.enum(['talk', 'stage', 'broadcast']).default('talk'),
    description: z.string().optional(),
    maxParticipants: z.number().default(100),
    speakerPermission: z.enum(['everyone', 'followers', 'invited']).default('invited'),
    tags: z.array(z.string()).optional(),
  })
  .passthrough();

export type RoomTemplate = z.infer<typeof ZRoomTemplate>;

export const ZSeriesEpisode = z
  .object({
    roomId: z.string(),
    scheduledStart: z.string(),
    episodeNumber: z.number(),
  })
  .passthrough();

export type SeriesEpisode = z.infer<typeof ZSeriesEpisode>;

export const ZSeries = withUnderscoreIdFallback(
  z
    .object({
      id: z.string(),
      title: z.string(),
      description: z.string().optional(),
      coverImage: z.string().optional().nullable(),
      houseId: z.string().optional().nullable(),
      createdBy: z.string(),
      recurrence: ZRecurrence,
      roomTemplate: ZRoomTemplate,
      episodes: z.array(ZSeriesEpisode).default([]),
      nextEpisodeNumber: z.number().default(1),
      isActive: z.boolean().default(true),
      createdAt: z.string(),
    })
    .passthrough(),
);

export type Series = z.infer<typeof ZSeries>;

// --- Recording ---

export const ZRecording = withUnderscoreIdFallback(
  z
    .object({
      id: z.string(),
      roomId: z.string(),
      roomTitle: z.string(),
      host: z.string(),
      status: z.enum(['recording', 'processing', 'ready', 'failed', 'deleted']),
      egressId: z.string(),
      objectKey: z.string(),
      fileSize: z.number().nullish(),
      durationMs: z.number().nullish(),
      startedAt: z.string(),
      stoppedAt: z.string().nullish(),
      access: z.enum(['public', 'participants']).default('public'),
      participantIds: z.array(z.string()).default([]),
      expiresAt: z.string(),
      createdAt: z.string(),
    })
    .passthrough(),
);

export type Recording = z.infer<typeof ZRecording>;

// --- Stream responses ---

export const ZStartStreamResponse = z
  .object({
    ingressId: z.string(),
    url: z.string(),
  })
  .passthrough();

export const ZGenerateStreamKeyResponse = z
  .object({
    rtmpUrl: z.string(),
    streamKey: z.string(),
  })
  .passthrough();

export const ZStreamInfo = z
  .object({
    title: z.string().optional(),
    image: z.string().optional(),
    description: z.string().optional(),
  })
  .passthrough();

export type StreamInfo = z.infer<typeof ZStreamInfo>;

// --- Room attachment for posts ---

export const ZRoomAttachment = z
  .object({
    roomId: z.string(),
    title: z.string(),
    status: z.enum(['scheduled', 'live', 'ended']).optional(),
    type: z.enum(['talk', 'stage', 'broadcast']).optional(),
    topic: z.string().optional(),
    host: z.string().optional(),
  })
  .passthrough();

export type RoomAttachment = z.infer<typeof ZRoomAttachment>;

// --- Validators ---

export function validateRoom(data: unknown): Room | null {
  const result = ZRoom.safeParse(data);
  if (result.success) return result.data;
  console.warn('[live] Invalid Room:', result.error.issues[0]);
  return null;
}

export function validateRooms(items: unknown[]): Room[] {
  if (!Array.isArray(items)) return [];
  const valid: Room[] = [];
  for (const item of items) {
    const parsed = ZRoom.safeParse(item);
    if (parsed.success) {
      valid.push(parsed.data);
    } else {
      console.warn('[live] Dropping invalid room:', parsed.error.issues[0]);
    }
  }
  return valid;
}

export function validateHouse(data: unknown): House | null {
  const result = ZHouse.safeParse(data);
  if (result.success) return result.data;
  console.warn('[live] Invalid House:', result.error.issues[0]);
  return null;
}

export function validateRecording(data: unknown): Recording | null {
  const result = ZRecording.safeParse(data);
  if (result.success) return result.data;
  console.warn('[live] Invalid Recording:', result.error.issues[0]);
  return null;
}

export function validateRecordings(items: unknown[]): Recording[] {
  if (!Array.isArray(items)) return [];
  const valid: Recording[] = [];
  for (const item of items) {
    const parsed = ZRecording.safeParse(item);
    if (parsed.success) valid.push(parsed.data);
  }
  return valid;
}

export function validateSeries(data: unknown): Series | null {
  const result = ZSeries.safeParse(data);
  if (result.success) return result.data;
  console.warn('[live] Invalid Series:', result.error.issues[0]);
  return null;
}
